#include <iostream>
#include <iomanip>
#include <string>
#include <conio.h>

using namespace std;


class Event {

private:

	struct node
	{
		string  Event_Name, Event_Manager_Name, Customer_Name, Date;
		double Number_of_Guest;

		struct node* next;

	};

	struct node* head = NULL;


public:

	void Menu();
	void Insert();
	void Search();
	void Update();
	void Delete();
	void Sorting();
	void Show();

};

//Functions
//Insert

void Event::Insert() {

	cout << "\t\t EVENT MANGMENT SYSTEM \t\t\n";

	cout << "\t\t ======================== \t\t\n\n";

	struct node* new_node;
	new_node = new node;

	cout << "\t\t Event Name \n";

	cin.ignore();
	getline(cin, new_node->Event_Name);

	cout << "\t\t =============\t\t\n";

	cout << "\t\t Event Manager Name \n";

	getline(cin, new_node->Event_Manager_Name);

	cout << "\t\t========================\t\t\n\n";

	cout << "\t\t Customer Name \n";

	getline(cin, new_node->Customer_Name);

	cout << "\t\t========================\t\t\n\n";

	cout << "\t\t Date Of Event \n";

	getline(cin, new_node->Date);

	cout << "\t\t========================\t\t\n\n";

	cout << "\t\t Total No Of Guest \t\t\n";

	cin >> new_node->Number_of_Guest;

	new_node->next = NULL;

	if (head == NULL) {

		head = new_node;

	}

	else {

		struct node* ptr = head;

		while (ptr->next != NULL) {

			ptr = ptr->next;

		}

		ptr->next = new_node;
	}

	cout << "\t\t New Event Inserted Succfully....\t\t\n ";


	cout << "\t\t ================================\t\t\n";

}


// Search

void Event::Search() {
	string Name;
	int k = 0;

	cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

	cout << "\t\t========================\t\t\n\n";

	if (head == NULL) {

		cout << "\t\t Link List is Empty...\n";
		cout << "\t\t =====================\n";
	}

	else {

		cin.ignore();

		cout << "\t\t Event Name\n";

		getline(cin, Name);

		cout << "\t\t =============\n";

		struct node* ptr = head;

		while (ptr != NULL) {

			if (Name == ptr->Event_Name) {

				cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

				cout << "\t\t========================\t\t\n\n";

				cout << "\t\t Event Name:\t" << ptr->Event_Name << endl;
				cout << "\t\t =============\n";

				cout << "\t\t Event Manager Name:\t" << ptr->Event_Manager_Name << endl;
				cout << "\t\t =============\n";

				cout << "\t\t Customer Name:\t" << ptr->Customer_Name << endl;
				cout << "\t\t =============\n";

				cout << "\t\t Date of Event: \t" << ptr->Date << endl;
				cout << "\t\t =============\n";

				cout << "\t\t Total No Of Guest:\t" << ptr->Number_of_Guest << endl;
				cout << "\t\t =============\n";

				k++;
			}

			ptr = ptr->next;

		}

		if (k == 0) {

			cout << "\t\t Event Name is Invalid......\n";

			cout << "\t\t =============================\n";
		}

	}
}


//Update

void Event::Update() {
	string Name;
	int k = 0;

	cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

	cout << "\t\t========================\t\t\n\n";

	if (head == NULL) {

		cout << "\t\t Link List is Empty...\n";
		cout << "\t\t =======================\n";
	}

	else {

		cin.ignore();

		cout << "\t\t Event Name\n";

		getline(cin, Name);
		cout << "\t\t ===========\n";

		struct node* ptr = head;

		while (ptr != NULL) {


			if (Name == ptr->Event_Name) {

				cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

				cout << "\t\t========================\t\t\n\n";

				cout << "\t\t Event Name:\t" << endl;

				getline(cin, ptr->Event_Name);
				cout << "\t\t =======================\n";

				cout << "\t\t Event Manager Name:\t" << endl;

				getline(cin, ptr->Event_Manager_Name);
				cout << "\t\t =======================\n";

				cout << "\t\t Customer Name:\t" << endl;

				getline(cin, ptr->Customer_Name);
				cout << "\t\t =======================\n";

				cout << "\t\t Date of Event: \t" << endl;

				getline(cin, ptr->Date);
				cout << "\t\t =======================\n";

				cout << "\t\t Total No Of Guest:\t" << endl;
				cout << "\t\t =======================\n";
				cin >> ptr->Number_of_Guest;

				k++;


				cout << "\t\t Update Event Record Successfully....\n";
				cout << "\t\t ====================================\n";
			}

			ptr = ptr->next;

		}

		if (k == 0) {

			cout << "\t\t Event Name is Invalid......\n";
			cout << "\t\t ===========================\n";
		}

	}
}


// Delete

void Event::Delete() {
	string Name;
	int k = 0;

	cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

	cout << "\t\t========================\t\t\n\n";

	if (head == NULL) {

		cout << "\t\t Link List is Empty...\n";
		cout << "\t\t =====================\n";
	}

	else {

		cout << "\t\t Event Name\n";

		cin.ignore();

		getline(cin, Name);
		cout << "\t\t =======================\n";

		if (Name == head->Event_Name) {

			struct node* ptr = head;

			head = head->next;

			free(ptr);

			cout << "\t\t Delete Event Successfully......\n";
			cout << "\t\t ===============================\n";

			k++;

		}

		else {

			struct node* ptr = head;

			while (ptr->next != NULL) {

				if (Name == ptr->next->Event_Name) {

					node* p = ptr->next;

					ptr->next = p->next;

					free(p);

					cout << "\t\t Delete Event Successfully......\n";
					cout << "\t\t ===============================\n";

					k++;

					break;
				}

				ptr = ptr->next;
			}
		}

		if (k == 0) {

			cout << "\t\t Event Name is Invalid........\n";
			cout << "\t\t =======================\n";

		}
	}
}

//Sorting


void Event::Sorting() {
	int count = 0;
	string t_Event_Name, t_Event_Manager, t_Customer_Name, t_Date;
	int t_Number_of_Guest;

	if (head == NULL) {

		cout << "\t\t Link List is Empty......\n";
		cout << "\t\t =======================\n";

		Menu();
	}


	struct node* ptr = head;

	struct node* ptr1;

	struct node* ptr2 = NULL;

	while (ptr->next != NULL) {
		ptr1 = ptr->next;

		bool flag = false;

		string min = ptr->Event_Name;

		while (ptr1 != NULL) {

			if (min > ptr1->Event_Name) {

				min = ptr1->Event_Name;

				ptr2 = ptr1;

				flag = true;
			}

			ptr1 = ptr1->next;

		}

		if (flag == true) {

			string temp = ptr->Event_Name;

			ptr->Event_Name = min;

			ptr2->Event_Name = temp;

		}

		ptr = ptr->next;

	}
}

// Show

void Event::Show() {

	cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

	cout << "\t\t========================\t\t\n\n";

	struct node* ptr = head;

	while (ptr != NULL) {

		cout << "\t\t Event Name:\t" << ptr->Event_Name;
		cout << "\n\t\t =======================\n";

		cout << "\n\t\t Event Manager Name:\t" << ptr->Event_Manager_Name;
		cout << "\n\t\t =======================\n";

		cout << "\n\t\t Customer Name:\t" << ptr->Customer_Name;
		cout << "\n\t\t =======================\n";

		cout << "\n\t\t Date of Event: \t" << ptr->Date;
		cout << "\n\t\t =======================\n";

		cout << "\n\t\t Total No Of Guest:\t" << ptr->Number_of_Guest;
		cout << "\n\t\t =======================\n";

		ptr = ptr->next;
	}
}

// Menu


void Event::Menu() {

	int choice;

	do
	{

		cout << "\t\tEVENT MANGMENT SYSTEM\t\t\n";

		cout << "\t\t========================\t\t\n\n";

		cout << "Press 1. \t Insert \n";
		cout << "\t\t ==============\n";

		cout << "Press 2. \t Search \n";
		cout << "\t\t ==============\n";

		cout << "Press 3. \t Update \n";
		cout << "\t\t ==============\n";

		cout << "Press 4. \t Delete \n";
		cout << "\t\t ==============\n";

		cout << "Press 5. \t Sorting \n";
		cout << "\t\t ==============\n";

		cout << "Press 6. \t Show \n";
		cout << "\t\t ==============\n";

		cout << "Press 7. \t EXIT\n";
		cout << "\t\t ==============\n";

		cout << "Please Enter Your Choice:\n";
		cin >> choice;
		cout << "\t\t =======================\n";


		switch (choice) {

		case 1: {

			Insert();

			break;
		}

		case 2:
		{

			Search();

			break;
		}

		case 3: {

			Update();

			break;
		}

		case 4: {

			Delete();

			break;
		}

		case 5: {

			Sorting();

			Show();

			break;
		}

		case 6: {

			Show();

			break;
		}

		case 7: {

			cout << "\t\t THANK YOU FOR YOUR SERVICES.......\n";
			cout << "\t\t =============================\n";

			cout << "\t\t EXIT......\n";

			break;

		}

		default: {

			cout << "Invalid Choice do you enter......\n";
			cout << "\t\t ============================\n";

			break;
		}
		}
	} while (choice != 7);
}

// Main

int main() {
	Event obj;

	obj.Menu();

	system("pause");

	return 0;
}